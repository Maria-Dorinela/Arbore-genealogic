/***
 * Clasa Parinte
 * @author dorinela
 *
 */
public class Parinte extends Copil
{
/***
 * Constructor cu parametru n
 * @param n
 */
	public Parinte(String n) {
		super(n);
		tip="Parinte";
		// TODO Auto-generated constructor stub
	}
	
	/***
	 * Constructor fara parametru
	 */
	public Parinte()
	{
		super();
	}
	
	
}
