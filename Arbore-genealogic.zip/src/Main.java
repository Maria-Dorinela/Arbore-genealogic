/***
 * Clasa Main
 * author dorinela
 * 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {

	static ArrayList<linie> lin;
	static ArrayList<linie> lin2;
	static ArrayList<Persoana> p;
	
	static Persoana root;
	
	private static String msg;
	

	public static void main(String[] args) {

		lin = new ArrayList<linie>();
		p = new ArrayList<Persoana>();
		citire();
		lin2 = lin;
		lin = sortare(lin);
		
		//afisare();
		principala();
		instantiere();
		
		
		/*for (int i = 0; i < p.size(); i++) {
			System.out.println(i + ". " + p.get(i).nume + " parinte:"+ p.get(i).parinte.nume + "\n" + " Copii:"+ afisareCopii(p.get(i)) + "\n" + " Frati:" + afisareFrati(p.get(i))+ "\n" + " Unchi:" +afisareUnchi(p.get(i)) + "\n"+" Nepoti:" + afisareNepoti(p.get(i)) + "\n" + "Var:" + afisareVar(p.get(i))+"\n"+"Tip:"+ p.get(i).tip +"\n"+"Referinta: "+p.get(i).referinta.nume+"\n");
		}*/
		
		Scanner sc = new Scanner(System.in);
		while (sc.hasNextLine()){
		String str = sc.nextLine();
		int index = cautare(str);
		
		mesaj(p.get(index));
		if(msg.equals("")==false)
		System.out.println(msg);
		}
	}
	
	/***
	 * transmite mesajul de la sursa la root pe lantul de mostenire
	 * @param sursa
	 */
	private static void mesaj(Persoana sursa)
	{
		if(sursa.equals(root))
			msg="";
		else
		{
			msg ="";
			msg+=sursa.getMesaj();
			trimitereMesaj(new Persoana("-"),sursa); 
		}
		
	}
	
	/***
	 * Citirea din fisier
	 */
	public static void citire() {
		File file = new File("in.txt");

		try {

			Scanner scanner = new Scanner(file);

			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				if (!line.equals("")){
				String[] v = line.split(" ");//bag intr-un vector prima persoana, relatia si a doua persoana
				if (v.length == 3) {
					linie e = new linie(v[0], v[2], v[1]);
					lin.add(e);//datele din vector le introduc in structura
				} else {
					linie e = new linie(v[0], "", "");//pentru root
					lin.add(e);
				}
				}
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/***
	 * Afisaza structura
	 */
	public static void afisare() {
		for (int i = 0; i < lin2.size(); i++) {
			System.out.println(lin2.get(i).A + " <" + lin2.get(i).rel + "> "+ lin2.get(i).B);
		}
	}
	
	/***
	 * sortez structura dupa relatie
	 * @param l structura pe care vreau sa o sortez
	 * @return structura sortata
	 */
	public static ArrayList<linie> sortare( ArrayList<linie> l){
		 ArrayList<linie> li = new ArrayList<linie>();
		 for(linie i : l)
		 {
			 if(i.rel.equals(""))
				 li.add(i);
		 }
		 for(linie i : l)
		 {
			 if(i.rel.equals("copil"))
				 li.add(i);
		 }
		 for(linie i : l)
		 {
			 if(i.rel.equals("parinte"))
				 li.add(i);
		 }
		 for(linie i : l)
		 {
			 if(i.rel.equals("frate"))
				 li.add(i);
		 }
		 for(linie i : l)
		 {
			 if(i.rel.equals("unchi"))
				 li.add(i);
		 }
		 for(linie i : l)
		 {
			 if(i.rel.equals("nepot"))
				 li.add(i);
		 }
		 for(linie i : l)
		 {
			 if(i.rel.equals("var"))
				 li.add(i);
		 }
		 return li;
	}

	/***
	 * In aceasta metoda parcurg structura si construiesc arborii
	 */
	public static void principala() {
		for (linie l : lin) {             //parcurg structura
			
			if(l.B.equals("") && l.rel.equals("")) //verific daca campurile 2 si 3 din structura sunt "vide"
			{
		        int root = cautare(l.A);//caut root
		        if(root != -1)//daca am gasit root
		        {
		        	p.get(root).parinte = null;//root are ca parinte null(nu are parinte)
		        }
		        
			}
			if (l.rel.equals("copil"))//daca relatia e "copil"
			{
				int copil = cautare(l.A);
				int parinte = cautare(l.B);

				if (copil == -1 && parinte == -1)   //daca nu exista nici copilul nici parintele in structura
				{
					// instantiere
					Copil C = new Copil(l.A);   //creez copilul
					Parinte P = new Parinte(l.B);   //creez parintele

					// Creare legaturi
					
					C.parinte = P;
					P.copii.add(C);
					
					// adaugare in vector
					p.add(C);
					p.add(P);
				}
				
				else if (copil == -1 && parinte != -1) //daca copilul nu exista si parintele exista
				{
					// instantiere
					Copil C = new Copil(l.A);  //creez copilul

					// creare legaturi
					C.parinte = p.get(parinte);
					p.get(parinte).copii.add(C);

					// adaugare
					p.add(C);
				}
				else if (parinte == -1 && copil != -1)  //daca parintele nu exista si copilul exista
				{
					// instantiere
					Parinte P = new Parinte(l.B);   //creez parintele
					Persoana P1 = p.get(copil).parinte;

					// creare legaturi

					if (P1.nume == null) //copilul exista dar nu are parinte
					{
						p.get(copil).parinte = P;
						P.copii.add(p.get(copil));
					}
					else if (P1.nume.equals("-")) //copilul exista dar are parinte anonim
					{

						ArrayList<Persoana> CopiiP1 = P1.copii; //
						P.copii.addAll(CopiiP1); //adaug totii copii parintelui anonim la parintele creat

						// adaugare
						setareParinte(CopiiP1, P);  //setez pentru copii parintelui anonim parintele creat

					}
					p.add(P); //adaug parintele in vector
				}

				
				  else if(parinte != 1 && copil != 1)//daca parintele exista si copilul exista
				  { 
					  Persoana P1 =p.get(copil).parinte; 
				      Persoana P2 = p.get(parinte);
				
				 if(p.get(copil).parinte == null) //daca copilul nu are parinte
				 {
					 //creare legaturi
					 p.get(copil).parinte = p.get(parinte);
					 p.get(parinte).copii.add(p.get(copil));
				 }
				
				 else if(p.get(copil).parinte.equals("-"))//daca copilul are parinte anonim
				 {
					//creare legaturi
					  ArrayList<Persoana> Copii = P1.copii;
					  P2.copii.addAll(Copii);
						setareParinte(Copii, P2);
				 }
				 
			}
			}
			
			else if(l.rel.equals("parinte")) //daca relatia e parinte
			{
				int parinte = cautare(l.A);
				int copil = cautare(l.B);
				if (parinte == -1 && copil == -1)//daca parintele nu exista si copilul nu exista
				{
					// instantiere
					Parinte P = new Parinte(l.A);  //creez parinte
					Copil C = new Copil(l.B);    //creez copil
					
					// Creare legaturi
					C.parinte = P;
					P.copii.add(C);	
					
					// adaugare in vector
					p.add(C);
					p.add(P);
				}
				if(parinte == -1 && copil != -1) //daca parintele nu exista si copilul exista
				{
					Parinte P = new Parinte(l.A);   //creez parinte
					if(p.get(copil).parinte.nume == null) //daca parintele copilului nu exista
					{
						//creare legaturi
					p.get(copil).parinte = P;
					P.copii.add(p.get(copil));
					}
					
					if(p.get(copil).parinte.nume.equals("-")) //daca parintele copilului e exista dar e anonim
					{
						//creare legaturi
						ArrayList<Persoana> Copii = p.get(copil).parinte.copii;
						P.copii.addAll(Copii);
						setareParinte(Copii, P);
					}
					p.add(P); //adaugare vector
				}
				
				if(parinte != -1 && copil == -1) //parintele exista, copilul nu exista
				{
					Copil C = new Copil(l.B);  //creez copil
					//fac legaturile
					p.get(parinte).copii.add(C);
					C.parinte = p.get(parinte);	
					//adaugare vector
					p.add(C);
				}
				
				if(parinte != -1 && copil != -1)//parintele exista, copilul exista
				{	
					

					if(p.get(copil).parinte.nume == null) //copilul nu are parinte
					{
						//creare legaturi
						p.get(copil).parinte = p.get(parinte);
						p.get(parinte).copii.add(p.get(copil));
					}
					if(p.get(copil).parinte.nume.equals("-"))//copilul are parinte dar e anonim
					{
						//creare legaturi
						ArrayList<Persoana> Copii = p.get(copil).parinte.copii;
						p.get(parinte).copii.addAll(Copii);
						setareParinte(Copii,p.get(parinte));
					}
					
				}
			}

			else if (l.rel.equals("frate")) //daca relatia e frate
			{
				int frate1 = cautare(l.A);
				int frate2 = cautare(l.B);

				if (frate1 == -1 && frate2 == -1) //nu exista nuci un frate
				{
					// instantiere
					Frate Frate1 = new Frate(l.A);
					Frate Frate2 = new Frate(l.B);
					Parinte anonim = new Parinte("-");

					// Legaturi
					anonim.copii.add(Frate1);
					anonim.copii.add(Frate2);
					Frate1.parinte = anonim;
					Frate2.parinte = anonim;

					// adaugare
					p.add(Frate1);
					p.add(Frate2);

				}
				else if (frate1 != -1 && frate2 == -1) //primul frate exista , al doilea nu exista
				{
					// instantiere
					Frate Frate2 = new Frate(l.B);

					// legaturi
					Persoana P = p.get(frate1).parinte;

					if (P.nume != null || P.nume.equals("-")) //daca parintele primului frate e anonim sau nu
					{
                         //crare legaturi
						Frate2.parinte = P;
						P.copii.add(Frate2);
						
					}
					 
				else if(P.nume == null) //daca primul frate nu are parinte
				{
						Parinte anonim = new Parinte("-"); //creare parinte anonim
						//creare legaturi
						p.get(frate1).parinte = anonim;
						Frate2.parinte = anonim;
						anonim.copii.add(Frate2);
						anonim.copii.add(p.get(frate1));

					}

					// adaugare
					p.add(Frate2);

				} 
				else if (frate1 == -1 && frate2 != -1) //primul frate nu exista, al doilea exista
				{
					// instantiere
					Frate Frate1 = new Frate(l.A);

					// legaturi
					Persoana P = p.get(frate2).parinte;
					
					if (P.nume != null) //al doilea frate are parinte
					{
						//creare legaturi
						Frate1.parinte = P;
						P.copii.add(Frate1);
					} 
					else if(P.nume == null)//al doilea frate nu are parinte
					{
						Parinte anonim = new Parinte("-"); //creez parinte anonim
						//creare legaturi
						p.get(frate2).parinte = anonim;
						Frate1.parinte = anonim;
						anonim.copii.add(Frate1);
						anonim.copii.add(p.get(frate2));
					}
					// adaugare
					p.add(Frate1);
				}

				else if (frate1 != -1 && frate2 != -1) //daca ambii frati exista deja in structura
				{
					
					Persoana P1 = p.get(frate1).parinte; //parintele primului frate
					Persoana P2 = p.get(frate2).parinte; //parintele celui de-al doilea frate
					
					 if(P1.nume != null && P2.nume != null)
					{
						if(P1.nume.equals(P2.nume))
						{
							
						}
					}
					
						if(P1.nume == null && P2.nume != null)
						{
							p.get(frate1).parinte = p.get(frate2).parinte;
							p.get(frate2).parinte.copii.add(p.get(frate1));
						}
						
						else if(P2.nume == null && P1.nume != null)
						{
							p.get(frate2).parinte = p.get(frate1).parinte;
							p.get(frate1).parinte.copii.add(p.get(frate2));
						}
						else if(P1.nume == null && P2.nume == null)
						{
							Parinte anonim = new Parinte("-");
							p.get(frate1).parinte = anonim;
							p.get(frate2).parinte = anonim;
							anonim.copii.add(p.get(frate1));
							anonim.copii.add(p.get(frate2));
						}
						
						else if (P1.nume.equals("-")) {
							ArrayList<Persoana> CopiiP1 = P1.copii;
							P2.copii.addAll(CopiiP1);
							setareParinte(CopiiP1, P2);
						} 
							else if(P2.nume.equals("-"))
							{
								ArrayList<Persoana> Copii_frate2 = P2.copii;
								P1.copii.addAll(Copii_frate2);
								setareParinte(Copii_frate2, P1);
							}
				}

			}
			
			else if (l.rel.equals("unchi"))//daca relatia e unchi
			{
				int unchi = cautare(l.A);
				int nepot = cautare(l.B);
				
				if(unchi == -1 && nepot == -1)
				{
					
					Unchi U = new Unchi(l.A);
					Nepot N = new Nepot(l.B);
					Parinte anonim_U = new Parinte("-");
					Parinte anonim_N = new Parinte("-");
					
			       //legaturi
					
					anonim_N.copii.add(N);
					N.parinte = anonim_N;
					anonim_U.copii.add(U);
					U.parinte = anonim_U;
					anonim_U.copii.add(anonim_N);
					anonim_N.parinte = anonim_U;
					
					//adaugare
					
					p.add(U);
					p.add(N);
					
				}
				
				else if(unchi == -1 && nepot != -1)
				{
					Unchi U = new Unchi(l.A);
					
					
					if(p.get(nepot).parinte.parinte.nume != null)
					{
						p.get(nepot).parinte.parinte.copii.add(U);
						U.parinte = p.get(nepot).parinte.parinte;
 					}
					
					else if(p.get(nepot).parinte.parinte.nume == null)
					{
						Parinte anonim_U = new Parinte("-");
						
						p.get(nepot).parinte.parinte = anonim_U;
						anonim_U.copii.add(p.get(nepot).parinte);
						U.parinte = anonim_U;
						anonim_U.copii.add(U);
					}
					
					else if(p.get(nepot).parinte.parinte.nume == null && p.get(nepot).parinte.nume == null)
					{
						Parinte anonim_U = new Parinte("-");
						Parinte anonim_N = new Parinte("-");
						
						p.get(nepot).parinte = anonim_N;
						anonim_N.copii.add(p.get(nepot));
						anonim_N.parinte = anonim_U;
						anonim_U.copii.add(anonim_N);
						p.get(unchi).parinte = anonim_U;
						anonim_U.copii.add(p.get(unchi));
					}
					p.add(U);
				}
				
				else if(unchi != -1 & nepot == -1)
				{
					Nepot N = new Nepot(l.B);
					Parinte anonim_N = new Parinte("-");
					
					anonim_N.parinte = p.get(unchi).parinte;
					p.get(unchi).parinte.copii.add(anonim_N);
					

					anonim_N.copii.add(N);
					N.parinte = anonim_N;
					p.add(N);
					
					
				}
				
				else if(unchi != -1 && nepot != -1)
				{
					if(p.get(unchi).parinte.nume == null && p.get(nepot).parinte.nume == null)
					{
						Parinte anonim_N = new Parinte("-");
						Parinte anonim_U = new Parinte("-");
						
						p.get(nepot).parinte = anonim_N;
						anonim_N.copii.add(p.get(nepot));
						anonim_N.parinte = anonim_U;
						anonim_U.copii.add(anonim_N);
						p.get(unchi).parinte = anonim_U;
						anonim_U.copii.add(p.get(unchi));
						
					}
					else if(p.get(unchi).parinte.nume == null && p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume == null)
					{
						Parinte anonim_U = new Parinte("-");
						
						p.get(nepot).parinte.parinte = anonim_U;
						anonim_U.copii.add(p.get(nepot).parinte);
						p.get(unchi).parinte = anonim_U;
						anonim_U.copii.add(p.get(unchi));
						
					}
					else if(p.get(unchi).parinte.nume != null && p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume == null)
					{
						p.get(nepot).parinte.parinte = p.get(unchi).parinte;
						p.get(unchi).parinte.copii.add(p.get(nepot).parinte);
					}
					else if(p.get(unchi).parinte.nume != null && p.get(nepot).parinte.nume == null)
					{
						Parinte anonim_N = new Parinte("-");
						
						p.get(nepot).parinte = anonim_N;
						anonim_N.copii.add(p.get(nepot));
						anonim_N.parinte = p.get(unchi).parinte;
						p.get(unchi).parinte.copii.add(anonim_N);
						
					}
					else if(p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume != null && p.get(unchi).parinte.nume == null)
					{
						p.get(unchi).parinte = p.get(nepot).parinte.parinte;
						p.get(nepot).parinte.parinte.copii.add(p.get(unchi));
						
					}
				}
				
			}
			
			else if(l.rel.equals("nepot"))
			{
				int nepot = cautare(l.A);
				int unchi = cautare(l.B);
				
				if(nepot == -1 && unchi == -1)
				{
					Nepot N = new Nepot(l.A);
					Unchi U = new Unchi(l.B);
					
					Parinte anonim_U = new Parinte("-");
					Parinte anonim_N = new Parinte("-");
					
			       //legaturi
					anonim_U.copii.add(U);
					U.parinte = anonim_U;
					
					anonim_U.copii.add(anonim_N);
					anonim_N.parinte = anonim_U;
					
					anonim_N.copii.add(N);
					N.parinte = anonim_N;
			
					//adaugare
					
					p.add(U);
					p.add(N);
					
				}
				
				else if(nepot == -1 && unchi != -1)
				{
					Nepot N = new Nepot(l.A);
					Parinte anonim_N = new Parinte("-");
					
					if(p.get(unchi).parinte.nume != null)
					{
					p.get(unchi).parinte.copii.add(anonim_N);
					anonim_N.parinte = p.get(unchi).parinte;
					anonim_N.copii.add(N);
					N.parinte = anonim_N;
					}
					
					else if(p.get(unchi).parinte.nume == null)
					{
						Parinte anonim_U = new Parinte("-");
						
						anonim_U.copii.add(p.get(unchi));
						p.get(unchi).parinte = anonim_U;
						
						anonim_U.copii.add(anonim_N);
						anonim_N.parinte = anonim_U;
						
						anonim_N.copii.add(N);
						N.parinte = anonim_N;
						
					}
					p.add(N);
				}
				
				else if(nepot != -1 && unchi == -1)
				{
					Unchi U = new Unchi(l.B);
					Parinte anonim_U = new Parinte("-");
					
					if(p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume == null)
					{
						p.get(nepot).parinte.parinte = anonim_U;
						anonim_U.copii.add(p.get(nepot).parinte);
						
						p.get(unchi).parinte = anonim_U;
						anonim_U.copii.add(p.get(unchi));
					}
					
					else if(p.get(nepot).parinte.nume == null && p.get(nepot).parinte.parinte.nume == null)
					{
						Parinte anonim_N = new Parinte("-");
						
						anonim_U.copii.add(p.get(unchi));
						p.get(unchi).parinte = anonim_U;
						
						anonim_U.copii.add(anonim_N);
						anonim_N.parinte = anonim_U;
						
						anonim_N.copii.add(p.get(nepot));
						p.get(nepot).parinte = anonim_N;
						
					}
					else if(p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume != null)
					{
						U.parinte = p.get(nepot).parinte.parinte;
						p.get(nepot).parinte.parinte.copii.add(U);
					}
					p.add(U);
				}
				
				else if(nepot != -1 && unchi != -1)
				{
					
					if(p.get(unchi).parinte.nume == null && p.get(nepot).parinte.nume == null)
					{
						Parinte anonim_N = new Parinte("-");
						Parinte anonim_U = new Parinte("-");
						
						p.get(nepot).parinte = anonim_N;
						anonim_N.copii.add(p.get(nepot));
						anonim_N.parinte = anonim_U;
						anonim_U.copii.add(anonim_N);
						p.get(unchi).parinte = anonim_U;
						anonim_U.copii.add(p.get(unchi));
						
					}
					else if(p.get(unchi).parinte.nume != null && p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume == null)
					{
						p.get(nepot).parinte.parinte = p.get(unchi).parinte;
						p.get(unchi).parinte.copii.add(p.get(nepot).parinte);
					}
					
					else if(p.get(unchi).parinte.nume == null && p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume == null)
					{
						Parinte anonim_U = new Parinte("-");
						
						p.get(nepot).parinte.parinte = anonim_U;
						anonim_U.copii.add(p.get(nepot).parinte);
						p.get(unchi).parinte = anonim_U;
						anonim_U.copii.add(p.get(unchi));
						
					}
					
					else if(p.get(unchi).parinte.nume != null && p.get(nepot).parinte.nume == null)
					{
						Parinte anonim_N = new Parinte("-");
						
						p.get(nepot).parinte = anonim_N;
						anonim_N.copii.add(p.get(nepot));
						anonim_N.parinte = p.get(unchi).parinte;
						p.get(unchi).parinte.copii.add(anonim_N);
						
					}
					
					
					else if(p.get(nepot).parinte.nume != null && p.get(nepot).parinte.parinte.nume != null && p.get(unchi).parinte.nume == null)
					{
						p.get(unchi).parinte = p.get(nepot).parinte.parinte;
						p.get(nepot).parinte.parinte.copii.add(p.get(unchi));
						
					}
					
					else if(p.get(unchi).parinte.nume != null && p.get(nepot).parinte.nume!= null && p.get(nepot).parinte.parinte.nume.equals("-"))
					{
						ArrayList<Persoana> c = p.get(nepot).parinte.parinte.copii;
						p.get(unchi).parinte.copii.addAll(c);
						setareParinte(c,p.get(unchi).parinte);
					}
					
					else if(p.get(unchi).parinte.nume != null && p.get(nepot).parinte.nume!= null && p.get(nepot).parinte.parinte.nume != null)
					{
						
					}
				}
			
			}
			
			else if(l.rel.equals("var"))
			{
				int var_1 = cautare(l.A);
				int var_2 = cautare(l.B);
				
				if(var_1 == -1 && var_2 == -1)
				{
					Parinte anonim = new Parinte("-");
					Parinte anonim_1 = new Parinte("-");
					Parinte anonim_2 = new Parinte("-");
					
					Var V1 = new Var(l.A);
					Var V2 = new Var(l.B);
					
					V1.parinte = anonim_1;
					anonim_1.copii.add(V1);
					anonim_1.parinte = anonim;
					anonim.copii.add(anonim_1);
					V2.parinte = anonim_2;
					anonim_2.copii.add(V2);
					anonim_2.parinte = anonim;
					anonim.copii.add(anonim_2);
					
					p.add(V1);
					p.add(V2);
				}
				
				if(var_1 != -1 && var_2 ==-1)
				{
					Var V2 = new Var(l.B);
					
					if(p.get(var_1).parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_1 = new Parinte("-");
						Parinte anonim_2 = new Parinte("-");
						
						p.get(var_1).parinte = anonim_1;
						anonim_1.copii.add(p.get(var_1));
						anonim_1.parinte = anonim;
						anonim.copii.add(anonim_1);
						V2.parinte = anonim_2;
						anonim_2.copii.add(V2);
						anonim_2.parinte = anonim;
						anonim.copii.add(anonim_2);
					}
					
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume == null )
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_1 = new Parinte("-");
						
						p.get(var_1).parinte.parinte = anonim;
						anonim.copii.add(p.get(var_1).parinte);
						V2.parinte = anonim_1;
						anonim_1.copii.add(V2);
						anonim_1.parinte = anonim;
						anonim.copii.add(anonim_1);	
					}
					
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume != null)
					{
						Parinte anonim = new Parinte("-");
						
						V2.parinte = anonim;
						anonim.copii.add(V2);
						
						anonim.parinte = p.get(var_1).parinte.parinte;
						p.get(var_1).parinte.parinte.copii.add(anonim);
					}
					
					p.add(V2);
				}
				
				if(var_1 == -1 && var_2 !=-1)
				{
					Var V1 = new Var(l.A);
					
					if(p.get(var_2).parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_1 = new Parinte("-");
						Parinte anonim_2 = new Parinte("-");
						
						p.get(var_2).parinte = anonim_1;
						anonim_1.copii.add(p.get(var_2));
						anonim_1.parinte = anonim;
						anonim.copii.add(anonim_1);
						V1.parinte = anonim_2;
						anonim_2.copii.add(V1);
						anonim_2.parinte = anonim;
						anonim.copii.add(anonim_2);
					}
					else if(p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_1 = new Parinte("-");
						
						p.get(var_2).parinte.parinte = anonim;
						anonim.copii.add(p.get(var_2).parinte);
						V1.parinte = anonim_1;
						anonim_1.copii.add(V1);
						anonim_1.parinte = anonim;
						anonim.copii.add(anonim_1);
					}
					else if(p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume != null)
					{
						Parinte anonim = new Parinte("-");
						
						V1.parinte = anonim;
						anonim.copii.add(V1);
						anonim.parinte = p.get(var_2).parinte.parinte;
						p.get(var_2).parinte.parinte.copii.add(anonim);
					}
					
					p.add(V1);
				}
				
				else if(var_1 != -1 && var_2 != -1)
				{
					if(p.get(var_1).parinte.nume == null && p.get(var_2).parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_1 = new Parinte("-");
						Parinte anonim_2 = new Parinte("-");
						
						p.get(var_1).parinte = anonim_1;
						anonim_1.copii.add(p.get(var_1));
						anonim_1.parinte = anonim;
						anonim.copii.add(anonim_1);
						p.get(var_2).parinte = anonim_2;
						anonim_2.copii.add(p.get(var_2));
						anonim_2.parinte = anonim;
						anonim.copii.add(anonim_2);
						
					}
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume == null && p.get(var_2).parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_2 = new Parinte("-");
						
						p.get(var_1).parinte.parinte = anonim;
						anonim.copii.add(p.get(var_1).parinte);
						p.get(var_2).parinte = anonim_2;
						anonim_2.copii.add(p.get(var_2));
						anonim_2.parinte = anonim;
						anonim.copii.add(anonim_2);
					}
					else if(p.get(var_1).parinte.nume == null && p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						Parinte anonim_1 = new Parinte("-");
						
						p.get(var_1).parinte = anonim_1;
						anonim_1.copii.add(p.get(var_1));
						anonim_1.parinte = anonim;
						anonim.copii.add(anonim_1);
						p.get(var_2).parinte.parinte = anonim;
						anonim.copii.add(p.get(var_2).parinte);
					}
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume == null && p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume == null)
					{
						Parinte anonim = new Parinte("-");
						
						p.get(var_1).parinte.parinte = anonim;
						anonim.copii.add(p.get(var_1).parinte);
						p.get(var_2).parinte.parinte = anonim;
						anonim.copii.add(p.get(var_2).parinte);
					}
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume != null && p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume != null)
					{
						
					}
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume != null && p.get(var_2).parinte.nume == null)
					{
						Parinte anonim_2 = new Parinte("-");
						
						p.get(var_2).parinte = anonim_2;
						anonim_2.copii.add(p.get(var_2));
						anonim_2.parinte = p.get(var_1).parinte.parinte;
						p.get(var_1).parinte.parinte.copii.add(anonim_2);
					}
					else if(p.get(var_1).parinte.nume == null && p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume != null)
					{
						Parinte anonim_1 = new Parinte("-");
						
						p.get(var_1).parinte = anonim_1;
						anonim_1.copii.add(p.get(var_1));
						anonim_1.parinte = p.get(var_2).parinte.parinte;
						p.get(var_2).parinte.parinte.copii.add(anonim_1);
					}
					else if(p.get(var_1).parinte.nume != null && p.get(var_1).parinte.parinte.nume != null && p.get(var_2).parinte.nume != null && p.get(var_2).parinte.parinte.nume == null)
					{
						p.get(var_2).parinte.parinte = p.get(var_1).parinte.parinte;
						p.get(var_1).parinte.parinte.copii.add(p.get(var_2).parinte);
					}
				}
			}
			}
	}

	/***
	 * cauta persoanele in structura dupa nume
	 * @param nume
	 * @return -1 daca nu a gasit si != -1 daca a gasit persoana respectiva
	 */
	public static int cautare(String nume) {
		int rez = -1;
		for (int i = 0; i < p.size(); i++) 
		{
			if (p.get(i).nume.equals(nume)) 
			{
				rez = i;
				break;
			}
		}
		return rez;
	}

	/***
	 * afisaza copii persoanei data ca parametru
	 * @param pp
	 * @return copii
	 */
	public static String afisareCopii(Persoana pp) {
		String rez = "[";
		for (int i = 0; i < pp.copii.size(); i++) {
			rez += pp.copii.get(i).nume;
			rez += ",";
		}
			
		return rez + "]";
	}
	
	/***
	 * afisaza fratii persoanei data ca parametru
	 * @param pp
	 * @return fratii persoanei data ca parametru
	 */
	public static String afisareFrati(Persoana pp){
		String rez = "[";
		Persoana tata = pp.parinte;
		ArrayList<Persoana> frati = tata.copii;
		
		if(tata.nume!=null){
			for(int j=0; j<frati.size(); j++){
				if(!frati.get(j).nume.equals(pp.nume))
				{
					rez += frati.get(j).nume;
					rez += ",";
				}
			}
			
			
		}
		return rez + "]";
	}
	
	/***
	 * afisaza unchi persoanei data ca parametru
	 * @param pp
	 * @return unchii persoanei
	 */
	
	public static String afisareUnchi(Persoana pp){
		String rez = "[";
		Persoana rad=pp.parinte.parinte;
		Persoana tata = pp.parinte;
		if(pp.parinte.nume != null)
		{
			if(pp.parinte.parinte.nume != null)
			{
				ArrayList<Persoana> unchi = rad.copii;
				for(int i=0; i<unchi.size(); i++)
				{
					if(unchi.get(i)!=tata)
					{
						rez+=unchi.get(i).nume;
						rez+=",";
					}
				}
			}
			else if(pp.parinte.parinte.nume == null)
				{
				rez += "";
				}
				
		}
		else if(pp.parinte.nume == null)
		{
			rez += "";
		}
		return rez+"]";
		
	}
	
	/***
	 * afisaza nepotii persoanei data ca parametru
	 * @param pp
	 * @return nepotii persoanei
	 */
	public static String afisareNepoti(Persoana pp)
	{
		String rez = "[";
		ArrayList<Persoana> P = pp.parinte.copii;
		if(P != null){
		for(int i=0; i<P.size(); i++)
		{
			if(!P.get(i).nume.equals(pp.nume))
				
			{
				for(int j=0; j<P.get(i).copii.size(); j++)
				rez += P.get(i).copii.get(j).nume;
			}
		}
		}
		return rez + "]";
	}
	
	
	/***
	 * afisaza verii persoanei data ca parametru
	 * @param pp
	 * @return ver bii persoanei
	 */
	public static String afisareVar(Persoana pp)
	{
		String rez = "[";
		
		
		if(pp.parinte.nume != null){
		if(pp.parinte.parinte.nume != null){
			ArrayList<Persoana> P = pp.parinte.parinte.copii;
		
			for(int i=0; i<P.size(); i++)
			{
				if(!P.get(i).nume.equals(pp.parinte.nume))
					
				{
					for(int j=0; j<P.get(i).copii.size(); j++)
					rez += P.get(i).copii.get(j).nume;
				}
			
		}
		}
		
		}
		
		return rez + "]";
	}

	public static String afisareArray(ArrayList<Persoana> l) {
		String rez = "(";
		for (int i = 0; i < l.size(); i++) {
			rez += l.get(i).nume;
			rez += ",";
		}
		return rez + ")";
	}

	/***
	 * seteaza ca parinte pe "parinte" pentru toti copii din ArrayList<Persoana> copii
	 * @param copii
	 * @param parinte
	 */
	public static void setareParinte(ArrayList<Persoana> copii, Persoana parinte) {
		for (int i = 0; i < copii.size(); i++) {
			copii.get(i).parinte = parinte;
		}
	}
	
	/***
	 * ia cu instantiez fiecare persoana din structura cu relatia in care apare ultima data
	 * deoarece eu sortez structura
	 * din acest motiv nu se mai pastreaza ultima instantiere
	 */
	public static void instantiere()
	{
		for(int i=0;i<lin2.size();i++)
		{
			int a = cautare(lin2.get(i).A);
			int b = cautare(lin2.get(i).B);
			
			
			if(lin2.get(i).rel.equals("parinte"))
			{
				p.get(a).tip = "Parinte";
				p.get(b).tip = "Copil";
				
				p.get(a).referinta = p.get(b);
				p.get(b).referinta = p.get(a);
			}
			else if(lin2.get(i).rel.equals("copil"))
			{
				p.get(a).tip = "Copil";
				p.get(b).tip = "Parinte";
				
				p.get(a).referinta = p.get(b);
				p.get(b).referinta = p.get(a);
			}
			else if(lin2.get(i).rel.equals("frate"))
			{
				p.get(a).tip = "Frate";
				p.get(b).tip = "Frate";
				
				p.get(a).referinta = p.get(b);
				p.get(b).referinta = p.get(a);
			}
			else if(lin2.get(i).rel.equals("var"))
			{
				p.get(a).tip = "Var";
				p.get(b).tip = "Var";
				
				p.get(a).referinta = p.get(b);
				p.get(b).referinta = p.get(a);
			}
			else if(lin2.get(i).rel.equals("unchi"))
			{
				p.get(a).tip = "Unchi";
				p.get(b).tip = "Nepot";
				
				p.get(a).referinta = p.get(b);
				p.get(b).referinta = p.get(a);
			}
			else if(lin2.get(i).rel.equals("nepot"))
			{
				p.get(a).tip = "Nepot";
				p.get(b).tip = "Unchi";
				
				p.get(a).referinta = p.get(b);
				p.get(b).referinta = p.get(a);
			}
			else
			{
				root = p.get(a);
				p.get(a).tip="Radacina";
				p.get(a).root=true;
			}
		}
	
		
	}
	
	
	/***
	 * trimitere mesaj de la o persoana la alta
	 * @param a
	 * @param sursa
	 */
	public static void trimitereMesaj(Persoana a,Persoana sursa)
	{
		
		if(sursa.equals(root)==false)
		{
			
			if(!a.nume.equals(sursa.referinta.nume) && sursa.referinta.root==false)
			{
				
				
				msg+=sursa.referinta.getMesaj();
				trimitereMesaj(sursa ,sursa.referinta);
			}
			else
			{
				
				if(sursa.parinte.root==false)
				{
					msg+=sursa.parinte.getMesaj();
					trimitereMesaj(sursa,sursa.parinte);
					
				}
			}
		}
				
	}
	
	/***
	 * trimiterea mesajului de la sursa la parintele sursei
	 * @param sursa
	 */
	public static void trimitereMesaj2(Persoana sursa)
	{
		if(sursa.equals(root)==false)
		{
			msg+=sursa.parinte.getMesaj();
			trimitereMesaj2(sursa.parinte);
		}
	}

}