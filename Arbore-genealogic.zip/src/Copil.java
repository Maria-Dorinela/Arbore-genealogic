/***
 * Clasa Copil
 * @author dorinela
 *
 */
public class Copil extends Persoana
{
/***
 * Constructor cu parametru n
 * @param n
 */
	public Copil(String n) {
		super(n);
		tip="Copil";
	}
	/***
	 * Constructor fara parametru
	 */
	public Copil()
	{
		super();
	}

}
