
/***
 * Clasa Var
 * @author dorinela
 *
 */
public class Var extends Nepot
{

	/***
	 * Constructor cu parametru n
	 * @param n
	 */
	public Var(String n) {
		super(n);
		tip="Var";
	}

}
