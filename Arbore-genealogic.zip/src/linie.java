/***
 * Clasa linie
 * @author dorinela
 * 
 *Aceasta clasa o folosesc pentru a creea o structura cu liniile din fisier
 *in care prima persoana e "A", a doua persoana e "B" iar relatia este "rel"
 */
public class linie 
{
	public String A;
	public String B;
	public String rel;
	
	/***
	 * Constructor cu e parametri
	 * @param a
	 * @param b
	 * @param r
	 */
	public linie(String a,String b,String r)
	{
		A = a;
		B = b;
		rel = r;
	}
	
}