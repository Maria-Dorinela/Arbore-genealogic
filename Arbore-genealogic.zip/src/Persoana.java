/***
 * Clasa Persoana
 * author dorinela
 */
import java.util.ArrayList;

import java.util.ArrayList;


public class Persoana 
{
	public boolean root;
	public String nume;
	public Persoana parinte;
	public String tip;
	public String mesaj;
	public Persoana referinta;
	
	public ArrayList<Persoana> copii;
	public ArrayList<Copil> frate;
	public ArrayList<Frate> unchi;
	
/***
 * Constructor cu parametru n
 * @param n
 */
	public Persoana(String n)
	{
		nume = n;
		copii = new ArrayList<Persoana>();
	    parinte = new Copil();
		
		frate = new ArrayList<Copil>();
		unchi = new ArrayList<Frate>();
		
		root=false;
	}
	
	/***
	 * Constructor fara parametru
	 */
	public Persoana()
	{
		
	}
	
	
	 /***
	  * 
	  * @return masajul specific fiecarei persoane
	  */
	public String getMesaj()
	{
		String mesaj = "";
		if(tip.equals("Copil"))
			mesaj= "I am a happy child.";
		
		else if(tip.equals("Parinte"))
			mesaj = "I am a happy child.I love being a parent.";
		
		
		else if(tip.equals("Nepot"))
			mesaj =  "I am a happy child.Being a nephew is the best.";
		
		else if(tip.equals("Var"))
			mesaj = "I am a happy child.Being a nephew is the best.Having a cousin is almost as good as having a brother.";
		
		else if(tip.equals("Frate"))
			mesaj = "I am a happy child.I love my brother.";
		
		
		else if(tip.equals("Unchi"))
			mesaj = "I am a happy child.I love my brother.I like having a nephew.";
		return mesaj;
	}
	
}
