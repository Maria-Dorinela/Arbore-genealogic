/***
 * Clasa Unchi
 * @author dorinela
 *
 */
public class Unchi extends Frate
{

	/***
	 * Constructor cu parametru n
	 * @param n
	 */
	public Unchi(String n) {
		super(n);
		tip="Unchi";
		
	}


}
