/***
 * clasa care contine structura folosita pentru dictionar
 * @author dorinela
 *
 */
class Hashnode {
	String key;   //key reprezinta cuvintele din dictioner
	lista data;   // data reprezinta lista cu indicii fiecarui cuvant
	Hashnode next;  

	/***
	 * Constructor pentru structura;
	 * @param k
	 * @param v
	 * @param n
	 */
	public Hashnode(String k, lista v, Hashnode n) {
		key = k;
		data = v;
		next = n;
	}
}
