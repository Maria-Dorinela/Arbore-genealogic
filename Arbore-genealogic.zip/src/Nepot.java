/***
 * Clasa Nepot
 * @author dorinela
 *
 */
public class Nepot extends Copil
{

	/***
	 * Constructor cu parametru n 
	 * @param n
	 */
	public Nepot(String n) {
		super(n);
		tip="Nepot";
		// TODO Auto-generated constructor stub
	}

}
