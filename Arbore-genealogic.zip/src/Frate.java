/***
 * Clasa Frate
 * @author dorinela
 *
 */
public class Frate extends Copil
{
/***
 * Constructor cu parametru n
 * @param n
 */
	public Frate(String n) {
		super(n);
		tip="Frate";
		
	}
	/***
	 * Constructor fara parametru
	 */
	public Frate()
	{
		super();
	}


}