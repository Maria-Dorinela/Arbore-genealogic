Sirbu Maria-Dorinela TEMA_2

Pentru efectuarea acestei teme am bagat datele din fisier intr-o structura.Am sortat structura dupa care am creat arborii.
La crearea arborilor am mers pe principiul:-daca nici un nod(persoana) nu exista in structura;
                                           -daca primul nod exista si al doile nu in structura;
					   - daca al doilea nod exista si primul nu in structura;
					   -daca ambele noduri exista in structura;
Mentionez ca implementarea nu e dintre cele mai bune deoarece am folosit foarte multe if-uri deci prin urmare si foarte mult cod.
Sortez structura inainte de a creea arborii pentru a unii corect arborii temporali creati pe parcurs.
Referitor la if-uri am comentat in cod cum sunt dar nu la toate relatiile deoarece toate merg pe acelasi principiu.
Folosesc o metoda pentru a instantia persoanele deoarece pierd ultima instantiere corecta din cauza sortarii.(in aceasta metoda folosesc structura nesortata).
Am creat o metoda in care am mesajele specifice fiecarei instantieri.
Am folosit trei medode pentru a transmite recursiv mesajele pe lantul de mostenire.
Sper ca implementarea sa fie usor de inteles desi nu e foarte eficienta.
Mersi mult.

